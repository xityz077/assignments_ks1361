# add 2 numbers
print(100 + 200)

# concatenate two strings
print('Jess' + 'Roy')

# merge two list
print([10, 20, 30] + ['Jessa', 'Emma', 'Kelly'])
