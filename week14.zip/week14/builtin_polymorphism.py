students = ['Emma', 'Jessa', 'Kelly']
school = 'ABC School'

# calculate count
print(f"There are {len(students)} elements in students[]")
print(f"There are {len(school)} characters in school Sting")
