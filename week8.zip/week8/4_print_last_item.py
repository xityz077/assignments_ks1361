new_list = []
for i in range(1, 101):
    new_list.append(i)

print(new_list[-1])
