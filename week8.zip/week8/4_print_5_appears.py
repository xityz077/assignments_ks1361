new_list = []
for i in range(1, 101):
    new_list.append(i)

count_of_5 = new_list.count(5)
print(f"The number 5 appears {count_of_5} times in the list")
