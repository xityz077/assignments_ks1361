# Print city at index 2
print("Print city at index [2]: ")
city = ("Texas", "New York", "New Jersey", "Utah")
print(city[2])

# Print city at index -3
print("\nPrint city at index [-3]: ")
city = ("Texas", "New York", "New Jersey", "Utah")
print(city[-3])

# Print city at index 1:3
print("\nPrint city at index [1:3]: ")
city = ("Texas", "New York", "New Jersey", "Utah")
print(city[1:3])
