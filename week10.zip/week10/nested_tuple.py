# Nested Tuple
print("Nested Tuple:")
nested_tuple = ("Dallas", "Frisco", [2, 8, 9], ("Denton", "Plano"))
print(nested_tuple)

# To see type of class being used
print("\nTo see type of class being used:")
city = ("Texas", "New York", "New Jersey", "Utah")
print(type(city))
