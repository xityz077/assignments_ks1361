tweet_msg = 'I love the UNT radio station, KNTU.'
if 'UNT' in tweet_msg:
    print('The tweet is about UNT!')

print("\n------------------------------------------\n")

phrase = 'team'
if 'T' not in phrase:
    print('There is no T in team.')
else:
    print('There is an T in team?')
