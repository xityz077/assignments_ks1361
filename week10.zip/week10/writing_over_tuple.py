# Define a tuple for recording dimensions of a rectangle
dimensions = (200, 50)
print("Original dimensions:")
for dimension in dimensions:
    print(dimension)

# Associate a new tuple with the existing variable
dimensions = (400, 100)
print("\nModified dimensions:")
for dimension in dimensions:
    print(dimension)
