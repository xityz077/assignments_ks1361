my_name = "Priyan Kumar"
print(my_name[0])
print(my_name[len(my_name)-1])
print(my_name[-1])

print("\n------------------------------------------\n")

for char in my_name:
    print(char)
