# Check for Item Existing in Tuple
print("Check for Item Existing in Tuple:")
city = ("Texas", "New York", "New Jersey", "Utah")
if "Utah" in city:
    print("Yes Item exist")
