my_list =[0,1,2]
my_tuple = (0,1,2)

print(my_list[0], '=', my_tuple[0])
print(my_list[1], '=', my_tuple[1])
print(my_list[2], '=', my_tuple[2])

# Tuple with strings
print("\nTuple with strings:")
city = ("Texas", "New York", "New Jersey", "Utah")
print(city)

# Tuple with integers
print("\nTuple with integers:")
num = (1, 2, 3, 4, 5)
print(num)

# Tuple with mixed datatyes
print("\nTuple with mixed datatyes:")
mix_tuple = ("Texas", "New York", "New Jersey", 1, 2, 3)
print(mix_tuple)


