# Convert Tuple to list
print("Convert Tuple to list")
my_tuple = (2, 4, 6, 8)
list_version = list(my_tuple)
print(f"list_version:\n{list_version}")

my_tuple = [2, 4, 6, 8]
tuple_version = tuple(my_tuple)
print(f"\ntuple_version:\n{tuple_version}")
