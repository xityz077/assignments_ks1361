class Student:
    # class variables
    school_name = "ABC School"

    # constructor
    def __init__(self, name, age):
        # instance variables
        self.name = name
        self.age = age

    def show(self):
        # access instance variables and class variables
        print('Student: ', self.name, self.age, Student.school_name)

    # instance method
    def change_age(self, new_age):
        # modify instance variable
        self.age = new_age

    # class method
    @classmethod
    def modify_school_name(cls, new_name):
        # modify class variable
        cls.school_name = new_name


s1 = Student("Harry", 12)

# call instance methods
print(f"\ncall instance methods, BEFORE:")
print('#' * 50)
s1.show()
s1.change_age(14)

# call class method
Student.modify_school_name('XYZ School')
# call instance methods
print(f"\ncall instance methods, AFTER:\nchange_age(14) && modify_school_name('XYZ School')")
print('#' * 50)
s1.show()
