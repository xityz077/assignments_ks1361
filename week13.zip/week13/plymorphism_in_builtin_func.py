students = ['Emma', 'Jessa', 'Kelly']
school = 'ABC School'

print('Reverse string')
for i in reversed(school):
    print(i, end=' ')

print('\nReverse string')
for i in reversed(students):
    print(i, end=' ')
