def print_patern():
    for i in range(5):
        print(' ' * i + '*' * (5 - i))


print_patern()
